import{_ as e,o as c,d as n}from"./index-I6TbVDK2.js";const r={};function t(a,o){return c(),n("main",null,"추천 여행지")}const _=e(r,[["render",t]]);export{_ as default};
