<template>
  <div>
    <h1>메모 앱</h1>
    <RouterView />
  </div>
</template>

<script setup>
import { RouterView } from "vue-router";
</script>

<style scoped></style>
